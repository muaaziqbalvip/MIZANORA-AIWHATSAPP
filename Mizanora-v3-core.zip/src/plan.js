// Auto-start planner: decides which user agents should run, from Firestore data. Pure function → unit-tested.
export const CHANNELS = ['whatsapp', 'telegram', 'business'];
const UID = /^[A-Za-z0-9]{20,40}$/;
const hasLLM = (c = {}) => Object.entries(c).some(([k, v]) => v && /_API_KEYS?$/.test(k) && !/^(WHATSAPP|TAVILY|BRAVE|SERPER|POLLINATIONS)/.test(k));
const ready = {
  whatsapp: (u) => !!u.cfg?.WHATSAPP_AGENT_API_KEY && hasLLM(u.cfg),
  telegram: (u) => !!u.cfg?.TELEGRAM_BOT_TOKEN && hasLLM(u.cfg),
  business: (u, b) => !!(b?.token && b?.phoneId && b?.appSecret) && hasLLM(u.cfg),
};
export function buildMatrix(users, bizMap = {}, conf = {}) {
  if (conf.paused) return { include: [] };
  const max = Math.min(200, Math.max(1, Number(conf.maxAgents) || 20)), include = [];
  for (const u of [...users].sort((a, b) => (a.created || 0) - (b.created || 0))) {
    if (u.status !== 'approved' || u.ctl === 'stop' || !UID.test(u.uid || '')) continue;
    for (const ch of CHANNELS) if ((u.channels || []).includes(ch) && ready[ch](u, bizMap[u.uid])) include.push({ uid: u.uid, ch });
  }
  return { include: include.slice(0, max) };
}
